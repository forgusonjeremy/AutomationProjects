/**
 * ST-08  WRITE AUDIT LOG
 * ─────────────────────────────────────────────────────────────────────────────
 * Calls the writeLogFile action to persist the complete run log to the
 * configured network share (NFS or SMB) as a timestamped JSON or CSV file.
 *
 * Log write failure is intentionally NON-FATAL. The full run detail is always
 * available in the vRO workflow execution log. A file write failure should not
 * prevent the mutex from being released in ST-09.
 *
 * The log summary (counts of each action type) is written to the vRO
 * workflow log here for quick visibility without needing to open the file.
 *
 * ── WORKFLOW ATTRIBUTE INPUTS ────────────────────────────────────────────────
 *   Name     Type     Description
 *   ────────────────────────────────────────────────────────────────────────
 *   runLog   string   Final JSON log array from ST-07
 *   runId    string   Used as filename component and JSON metadata
 *   dryRun   boolean  Appended to filename as _DRYRUN suffix when true
 *
 * ── WORKFLOW ATTRIBUTE OUTPUTS ───────────────────────────────────────────────
 *   Name             Type     Description
 *   ────────────────────────────────────────────────────────────────────────
 *   logFilePath      string   Absolute path of the written log file, or ""
 *   logWriteSuccess  boolean  True if file was written successfully
 */

var MODULE = "com.company.snapshotcleanup";
var logEntries = JSON.parse(runLog || "[]");

// ── Compute summary counts ────────────────────────────────────────────────────
var counts = { deleted: 0, dry_run: 0, skipped: 0, deferred: 0, error: 0, enum_error: 0 };
for each (var entry in logEntries) {
    if (counts.hasOwnProperty(entry.action)) {
        counts[entry.action]++;
    }
}

System.log("════════════════════════════════════════════════════");
System.log("  Run summary: " + runId);
System.log("  deleted    : " + counts.deleted);
System.log("  dry_run    : " + counts.dry_run);
System.log("  skipped    : " + counts.skipped);
System.log("  deferred   : " + counts.deferred);
System.log("  errors     : " + counts.error);
System.log("  enum_errors: " + counts.enum_error);
System.log("  total      : " + logEntries.length);
System.log("════════════════════════════════════════════════════");

// ── Write log file ────────────────────────────────────────────────────────────
logFilePath     = "";
logWriteSuccess = false;

try {
    var writeResult = JSON.parse(System.getModule(MODULE).writeLogFile(
        runLog,
        runId,
        dryRun
    ));

    logWriteSuccess = writeResult.success || false;
    logFilePath     = writeResult.filePath || "";

    if (logWriteSuccess) {
        System.log("[ST-08] Audit log written: " + logFilePath);
    } else {
        System.error("[ST-08] Audit log write failed: " + (writeResult.error || "unknown error"));
        System.warn("[ST-08] Full run data is still available in the vRO workflow execution log.");
    }
} catch (e) {
    System.error("[ST-08] writeLogFile threw: " + e.message);
    System.warn("[ST-08] Continuing to ST-09 to ensure mutex is released.");
}
