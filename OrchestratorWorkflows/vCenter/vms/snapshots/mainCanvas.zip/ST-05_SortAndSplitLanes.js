/**
 * ST-05  SORT & SPLIT EXECUTION LANES
 * ─────────────────────────────────────────────────────────────────────────────
 * Two responsibilities:
 *
 * 1. CHAIN-ORDER SORT
 *    Snapshot trees in vSphere are parent-child relationships. A parent
 *    snapshot cannot be safely deleted while any of its children still exist.
 *    We sort candidates so that children always appear before their parents
 *    in the processing queue. Within the same VM, oldest snapshots (by age)
 *    are processed first among siblings to maximise storage reclaim per run.
 *
 * 2. LANE SPLIT
 *    Powered-off VM consolidations impose no guest stun lock and are processed
 *    in a dedicated fast lane (ST-07) with no per-vCenter concurrency limit.
 *    Powered-on VMs go to the throttled lane (ST-06) with full governor and
 *    concurrency enforcement.
 *
 * ── WORKFLOW ATTRIBUTE INPUTS ────────────────────────────────────────────────
 *   Name                Type    Description
 *   ────────────────────────────────────────────────────────────────────────
 *   allCandidatesJson   string  Flat candidate array from ST-03
 *
 * ── WORKFLOW ATTRIBUTE OUTPUTS ───────────────────────────────────────────────
 *   Name                Type    Description
 *   ────────────────────────────────────────────────────────────────────────
 *   onCandidatesJson    string  JSON array — powered-on and suspended VMs
 *   offCandidatesJson   string  JSON array — powered-off VMs only
 */

var allCandidates = JSON.parse(allCandidatesJson || "[]");

// ── Step 1: Chain-order sort ──────────────────────────────────────────────────
// Topological sort: children before parents.
// The comparator checks if either candidate is the direct parent of the other.
// For unrelated snapshots, sort by age descending (oldest first).
allCandidates.sort(function(a, b) {
    // a is a child of b — a must come first
    if (a.parentSnapshotMoRef !== null &&
        a.parentSnapshotMoRef === b.snapshotMoRef) {
        return -1;
    }
    // b is a child of a — b must come first
    if (b.parentSnapshotMoRef !== null &&
        b.parentSnapshotMoRef === a.snapshotMoRef) {
        return 1;
    }
    // Unrelated: oldest first (maximise storage reclaim early in the run)
    return b.snapshotAgeMinutes - a.snapshotAgeMinutes;
});

// ── Step 2: Split into execution lanes ───────────────────────────────────────
var onCandidates  = [];
var offCandidates = [];

for each (var c in allCandidates) {
    if (c.vmPowerState === "poweredOff") {
        offCandidates.push(c);
    } else {
        // poweredOn and suspended both go to the throttled lane
        // (suspended VMs have disk I/O from snapshot operations even though
        //  they are not running guest workloads)
        onCandidates.push(c);
    }
}

onCandidatesJson  = JSON.stringify(onCandidates);
offCandidatesJson = JSON.stringify(offCandidates);

System.log("[ST-05] Sort complete. Chain-ordered " + allCandidates.length + " candidates.");
System.log("[ST-05] Powered-on / suspended lane : " + onCandidates.length);
System.log("[ST-05] Powered-off fast lane       : " + offCandidates.length);
