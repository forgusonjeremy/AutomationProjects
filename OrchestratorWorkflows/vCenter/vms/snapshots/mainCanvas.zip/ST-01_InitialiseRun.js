/**
 * ST-01  INITIALISE RUN
 * ─────────────────────────────────────────────────────────────────────────────
 * First scriptable task in the workflow. Sets up all derived runtime values
 * from the workflow input parameters and initialises the shared log array.
 *
 * PURPOSE:
 *   Convert human-readable input values into the unit forms used internally
 *   (GB → bytes, seconds → ms), generate a unique run ID, and set up the
 *   empty log array that will accumulate entries throughout the run.
 *
 * ── WORKFLOW INPUT BINDINGS (bind from workflow Inputs tab) ─────────────────
 *   Name                    Type      Default   Description
 *   ──────────────────────────────────────────────────────────────────────────
 *   maxAgeMinutes           number    60        Snapshot age threshold in minutes
 *   nameMatchString         string    ""        Whitelist filter — snapshot name must contain this
 *   descIgnoreString        string    ""        Skip filter — skip snap if description contains this
 *   dryRun                  boolean   true      When true, no deletions are performed
 *   latencyThresholdMs      number    30        VMFS/NFS: max projected latency in ms
 *   vsanCongestionThresh    number    50        vSAN: max projected congestion (0-255)
 *   vsanResyncThresholdGB   number    10        vSAN: max projected resync queue in GB
 *   maxParallelPerVcenter   number    3         Max concurrent consolidation tasks per vCenter
 *   governorPollIntervalSec number    30        Governor polling interval in seconds
 *   taskTimeoutSeconds      number    1800      Per-task vCenter task timeout in seconds
 *
 * ── WORKFLOW ATTRIBUTE OUTPUTS (bind to workflow Attributes tab) ─────────────
 *   Name                    Type      Description
 *   ──────────────────────────────────────────────────────────────────────────
 *   runId                   string    Unique run identifier (SCR-YYYY-MM-DDTHH-MM-SS)
 *   runLog                  string    JSON array — accumulates log entries (starts as "[]")
 *   vsanResyncThresholdBytes number   vsanResyncThresholdGB converted to bytes
 *   govPollMs               number    governorPollIntervalSec converted to milliseconds
 *   maxParallel             number    Alias of maxParallelPerVcenter (validated, min 1)
 */

// ── Generate unique run ID ───────────────────────────────────────────────────
runId = "SCR-" + new Date().toISOString().replace(/[:.]/g, "-").substring(0, 19);

// ── Convert threshold units ──────────────────────────────────────────────────
vsanResyncThresholdBytes = (vsanResyncThresholdGB || 10) * 1073741824;
govPollMs                = (governorPollIntervalSec || 30) * 1000;
maxParallel              = Math.max(1, maxParallelPerVcenter || 3);

// ── Initialise empty log array ───────────────────────────────────────────────
runLog = "[]";

// ── Log startup banner ───────────────────────────────────────────────────────
System.log("════════════════════════════════════════════════════");
System.log("  Adaptive Snapshot Cleanup — run started");
System.log("  Run ID   : " + runId);
System.log("  Dry run  : " + dryRun);
System.log("  Age limit: " + (maxAgeMinutes || 60) + " minutes");
System.log("  Name filter : " + (nameMatchString  || "(none)"));
System.log("  Desc ignore : " + (descIgnoreString || "(none)"));
System.log("  Latency threshold : " + (latencyThresholdMs || 30) + " ms");
System.log("  vSAN congestion   : " + (vsanCongestionThresh || 50));
System.log("  vSAN resync       : " + (vsanResyncThresholdGB || 10) + " GB");
System.log("  Max parallel/VC   : " + maxParallel);
System.log("  Governor poll     : " + (governorPollIntervalSec || 30) + " s");
System.log("  Task timeout      : " + (taskTimeoutSeconds || 1800) + " s");
System.log("════════════════════════════════════════════════════");
