/**
 * ST-07  PROCESS POWERED-OFF VMs (FAST LANE)
 * ─────────────────────────────────────────────────────────────────────────────
 * Processes the powered-off VM candidate queue. Key differences from ST-06:
 *
 *   - NO per-vCenter VM concurrency limit (no stun lock risk)
 *   - Still subject to the full adaptive I/O governor (consolidation still
 *     generates storage I/O on shared datastores)
 *   - Inherits datastoreState calibration data from ST-06 so the governor
 *     has learned impact deltas from the powered-on lane where available
 *
 * Powered-off VMs span all vCenters in a single flat queue rather than being
 * grouped per-vCenter, since there is no concurrency limit to manage.
 *
 * ── WORKFLOW ATTRIBUTE INPUTS ────────────────────────────────────────────────
 *   Name                     Type    Description
 *   ──────────────────────────────────────────────────────────────────────────
 *   offCandidatesJson        string  Powered-off candidates from ST-05
 *   datastoreStateJson       string  Governor calibration inherited from ST-06
 *   runId                    string  For log entry annotation
 *   runLog                   string  Current log JSON — entries appended here
 *   dryRun                   boolean Skip actual deletion when true
 *   latencyThresholdMs       number  VMFS/NFS governor threshold
 *   vsanCongestionThresh     number  vSAN governor threshold
 *   vsanResyncThresholdBytes number  vSAN resync queue threshold in bytes
 *   govPollMs                number  Governor polling interval in ms
 *   taskTimeoutSeconds       number  Per-task vCenter task timeout
 *
 * ── WORKFLOW ATTRIBUTE OUTPUTS ───────────────────────────────────────────────
 *   Name                Type    Description
 *   ──────────────────────────────────────────────────────────────────────────
 *   runLog              string  Updated JSON log array (final, passed to ST-08)
 *   datastoreStateJson  string  Updated governor state (informational — run ends after this)
 */

var MODULE = "com.company.snapshotcleanup";
var offCandidates  = JSON.parse(offCandidatesJson  || "[]");
var logEntries     = JSON.parse(runLog || "[]");
var datastoreState = JSON.parse(datastoreStateJson || "{}");

System.log("[ST-07] Processing " + offCandidates.length + " powered-off VM candidate(s).");

if (offCandidates.length === 0) {
    System.log("[ST-07] No powered-off candidates — skipping.");
    runLog = JSON.stringify(logEntries);
} else {

    // Build a lookup of SDK connections by name for fast resolution
    var vcConnLookup = {};
    var allVCs = VcPlugin.allSdkConnections;
    for each (var sdkConn in allVCs) {
        vcConnLookup[sdkConn.name || sdkConn.url] = sdkConn;
    }

    for (var i = 0; i < offCandidates.length; i++) {
        var candidate = offCandidates[i];
        var dsRefs    = candidate.datastoreMoRefs || [];
        var vcConn    = vcConnLookup[candidate.vcenterName] || null;

        if (!vcConn) {
            System.error("[ST-07] Cannot resolve vCenter connection for: " +
                         candidate.vcenterName + " — skipping " + candidate.vmName);
            logEntries.push(makeEntry(candidate, "skipped", false,
                                      "vCenter connection not found", null, 0));
            continue;
        }

        // ── Adaptive governor pre-check (no concurrency limit, still I/O-governed) ──
        var governorApproved = checkGovernor(vcConn, dsRefs, candidate.vmName, datastoreState);

        if (!governorApproved) {
            var pollAttempts    = 0;
            var maxPollAttempts = 120;
            while (!governorApproved && pollAttempts < maxPollAttempts) {
                System.log("[ST-07] Governor HOLD for (off) VM=" + candidate.vmName +
                           " (attempt " + (pollAttempts + 1) + "/" + maxPollAttempts + ")");
                System.sleep(govPollMs);
                pollAttempts++;
                governorApproved = checkGovernor(vcConn, dsRefs, candidate.vmName, datastoreState);
            }

            if (!governorApproved) {
                System.warn("[ST-07] Governor max wait exceeded for (off) VM=" + candidate.vmName +
                            " snap=" + candidate.snapshotName + " — deferring.");
                logEntries.push(makeEntry(candidate, "deferred", false,
                                          "Governor max wait exceeded", null, 0));
                continue;
            }
        }

        // ── Execute deletion ──────────────────────────────────────────────────
        var resultJson = System.getModule(MODULE).deleteSnapshot(
            vcConn,
            candidate.vmMoRef,
            candidate.snapshotMoRef,
            candidate.snapshotName,
            candidate.vmName,
            JSON.stringify(dsRefs),
            dryRun,
            taskTimeoutSeconds || 1800
        );

        var res = JSON.parse(resultJson);

        // ── Calibrate governor ────────────────────────────────────────────────
        if (!dryRun && res.success && !res.skipped) {
            var preArr  = JSON.parse(res.preMetricsJson  || "[]");
            var postArr = JSON.parse(res.postMetricsJson || "[]");
            for each (var pm in preArr) {
                if (!datastoreState[pm.datastoreMoRef]) datastoreState[pm.datastoreMoRef] = {};
                datastoreState[pm.datastoreMoRef].lastPre = pm;
            }
            for each (var pm2 in postArr) {
                if (!datastoreState[pm2.datastoreMoRef]) datastoreState[pm2.datastoreMoRef] = {};
                datastoreState[pm2.datastoreMoRef].lastPost = pm2;
            }
        }

        // ── Log entry ─────────────────────────────────────────────────────────
        var action = dryRun ? "dry_run"
                   : res.skipped ? "skipped"
                   : res.success ? "deleted"
                   : "error";
        logEntries.push(makeEntry(candidate, action,
            res.success || (dryRun && !res.skipped),
            res.skipReason, res.error, res.durationMs));
    }

    datastoreStateJson = JSON.stringify(datastoreState);
    runLog = JSON.stringify(logEntries);
    System.log("[ST-07] Powered-off fast lane complete.");
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function checkGovernor(vcConn, dsRefs, vmName, dsState) {
    if (!dsRefs || dsRefs.length === 0) return true;

    var currentMetrics = [];
    for each (var dsRef in dsRefs) {
        try {
            currentMetrics.push(JSON.parse(
                System.getModule(MODULE).getDatastoreMetrics(vcConn, dsRef)
            ));
        } catch (e) {
            System.warn("[ST-07] Could not sample datastore " + dsRef + ": " + e.message);
        }
    }

    var preArr = [], postArr = [];
    for each (var dsRef2 in dsRefs) {
        var st = dsState[dsRef2];
        if (st) {
            if (st.lastPre)  preArr.push(st.lastPre);
            if (st.lastPost) postArr.push(st.lastPost);
        }
    }

    var govResult = JSON.parse(System.getModule(MODULE).adaptiveGovernorCheck(
        JSON.stringify(currentMetrics),
        JSON.stringify(preArr),
        JSON.stringify(preArr),
        JSON.stringify(postArr),
        latencyThresholdMs       || 30,
        vsanCongestionThresh     || 50,
        vsanResyncThresholdBytes || 10737418240
    ));

    if (!govResult.approved) {
        System.log("[ST-07] Governor DENY for (off) VM=" + vmName + ": " + govResult.reason);
    }
    return govResult.approved;
}

function makeEntry(candidate, action, success, skipReason, error, durationMs) {
    return {
        timestampMs:        new Date().getTime(),
        runId:              runId,
        vCenter:            candidate.vcenterName  || "",
        vmName:             candidate.vmName       || "",
        vmPowerState:       candidate.vmPowerState || "",
        snapshotName:       candidate.snapshotName || "",
        snapshotDesc:       candidate.snapshotDesc || "",
        snapshotAgeMinutes: candidate.snapshotAgeMinutes || 0,
        action:             action,
        success:            success,
        skipReason:         skipReason || null,
        datastoreMoRefs:    candidate.datastoreMoRefs || [],
        durationMs:         durationMs || 0,
        error:              error || null
    };
}
