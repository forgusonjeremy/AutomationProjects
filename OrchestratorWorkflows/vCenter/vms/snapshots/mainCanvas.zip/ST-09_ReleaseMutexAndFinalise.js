/**
 * ST-09  RELEASE MUTEX & FINALISE
 * ─────────────────────────────────────────────────────────────────────────────
 * Final task in the normal execution path. Unconditionally releases the
 * mutex lock and writes a structured run summary to the workflow output
 * attribute. This task MUST always execute — connect it to ST-08's success
 * output AND to the Exception Handler's success output so the lock is
 * released regardless of how the workflow exits.
 *
 * WHY THIS IS A SEPARATE TASK:
 *   In the monolithic version, lock release was buried inside a function
 *   called from multiple code paths. As a discrete task it is:
 *     - Visible on the workflow canvas as a named step
 *     - Independently retryable if it fails (vRO retry on error)
 *     - Clearly auditable in the vRO execution timeline
 *
 * ── WORKFLOW ATTRIBUTE INPUTS ────────────────────────────────────────────────
 *   Name             Type                  Description
 *   ────────────────────────────────────────────────────────────────────────
 *   lockEl           ConfigurationElement  RuntimeState config element from ST-02
 *   runId            string               For summary and logging
 *   runLog           string               Final log JSON — for summary counts
 *   logFilePath      string               Written by ST-08 — included in summary
 *   logWriteSuccess  boolean              Written by ST-08 — included in summary
 *
 * ── WORKFLOW ATTRIBUTE OUTPUTS ───────────────────────────────────────────────
 *   Name             Type    Description
 *   ────────────────────────────────────────────────────────────────────────
 *   runSummaryJson   string  Structured summary of the run — suitable for binding
 *                            to a workflow output attribute visible in the vRO UI
 *                            and in the execution details pane.
 *
 * ── EXCEPTION HANDLER USAGE ──────────────────────────────────────────────────
 *   The Exception Handler scriptable task should call this same lock-release
 *   logic (or route to ST-09 directly) to guarantee the mutex is cleared on
 *   abnormal exit. See ExceptionHandler.js for the handler implementation.
 */

var logEntries = JSON.parse(runLog || "[]");

// ── Compute final counts ──────────────────────────────────────────────────────
var counts = { deleted: 0, dry_run: 0, skipped: 0, deferred: 0, error: 0, enum_error: 0 };
for each (var entry in logEntries) {
    if (counts.hasOwnProperty(entry.action)) {
        counts[entry.action]++;
    }
}

// ── Release mutex ─────────────────────────────────────────────────────────────
var lockReleased = false;
try {
    if (lockEl) {
        lockEl.setAttributeWithKey("runLock", "");
        lockReleased = true;
        System.log("[ST-09] Mutex released: " + runId);
    } else {
        System.warn("[ST-09] lockEl is null — mutex may already have been released or was never acquired.");
    }
} catch (le) {
    System.error("[ST-09] CRITICAL: Could not release mutex lock! " +
                 "Manual clear required in SnapshotCleanup/RuntimeState. Error: " + le.message);
}

// ── Build structured run summary ──────────────────────────────────────────────
var summary = {
    runId:           runId,
    completedAt:     new Date().toISOString(),
    lockReleased:    lockReleased,
    logFilePath:     logFilePath      || "",
    logWriteSuccess: logWriteSuccess  || false,
    counts: {
        deleted:    counts.deleted,
        dry_run:    counts.dry_run,
        skipped:    counts.skipped,
        deferred:   counts.deferred,
        errors:     counts.error,
        enumErrors: counts.enum_error,
        total:      logEntries.length
    },
    outcome: counts.error > 0   ? "COMPLETED_WITH_ERRORS"
           : counts.deferred > 0 ? "COMPLETED_WITH_DEFERRALS"
           : "SUCCESS"
};

runSummaryJson = JSON.stringify(summary, null, 2);

System.log("[ST-09] Run outcome: " + summary.outcome);
System.log("[ST-09] Run complete: " + runId);
