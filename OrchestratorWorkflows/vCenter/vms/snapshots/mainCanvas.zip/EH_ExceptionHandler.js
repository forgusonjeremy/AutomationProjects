/**
 * EXCEPTION HANDLER SCRIPTABLE TASK
 * ─────────────────────────────────────────────────────────────────────────────
 * Attached to the Exception Handler element on the vRO workflow canvas.
 * Connect the error output of EVERY scriptable task (ST-01 through ST-09)
 * to this handler element.
 *
 * RESPONSIBILITIES:
 *   1. Distinguish CLEAN_EXIT sentinel throws (ST-04 early exit, ST-02 mutex
 *      abort) from genuine runtime errors
 *   2. Attempt mutex lock release unconditionally
 *   3. Log the exception details to the vRO workflow log
 *   4. Set the workflowOutcome attribute so the calling system or vRA knows
 *      whether this was an abort, a clean no-op, or a genuine failure
 *
 * VERO CANVAS SETUP:
 *   - Add an Exception element to the canvas
 *   - Draw error transitions from ALL scriptable tasks to this element
 *   - Add this script as the Exception element's scriptable task body
 *   - The Exception element should NOT have a "throw" at the end if you want
 *     the workflow to end in a non-error state for CLEAN_EXIT and MUTEX_ABORT
 *
 * ── WORKFLOW ATTRIBUTE INPUTS ────────────────────────────────────────────────
 *   Name        Type                  Description
 *   ────────────────────────────────────────────────────────────────────────
 *   errorCode   string               vRO built-in — the thrown error message
 *   lockEl      ConfigurationElement  May be null if error occurred before ST-02
 *   runId       string               May be empty if error occurred in ST-01
 *   runLog      string               May be empty if error occurred early
 *   dryRun      boolean              For log write call
 *
 * ── WORKFLOW ATTRIBUTE OUTPUTS ───────────────────────────────────────────────
 *   Name              Type    Description
 *   ────────────────────────────────────────────────────────────────────────
 *   workflowOutcome   string  "CLEAN_EXIT" | "MUTEX_ABORT" | "ERROR"
 *   runSummaryJson    string  Minimal summary for this exit path
 */

var MODULE = "com.company.snapshotcleanup";

// errorCode is the vRO built-in exception binding — bind it in the
// Exception Handler's input bindings as type "string"
var errorMsg = errorCode || "Unknown error";

System.log("[EH] Exception handler invoked. Message: " + errorMsg);

// ── Classify the exit type ────────────────────────────────────────────────────
var isMutexAbort = (errorMsg.indexOf("ABORT: Another run is active") === 0);
var isCleanExit  = (errorMsg.indexOf("CLEAN_EXIT:") === 0);
var isRealError  = !isMutexAbort && !isCleanExit;

if (isMutexAbort) {
    workflowOutcome = "MUTEX_ABORT";
    System.warn("[EH] Classification: MUTEX_ABORT — lock was held by another run. No cleanup needed.");
} else if (isCleanExit) {
    workflowOutcome = "CLEAN_EXIT";
    System.log("[EH] Classification: CLEAN_EXIT — no candidates found, run completed cleanly.");
} else {
    workflowOutcome = "ERROR";
    System.error("[EH] Classification: ERROR — unexpected exception: " + errorMsg);
}

// ── Attempt log write for real errors ────────────────────────────────────────
// MUTEX_ABORT: lock is not ours — do NOT write (runLog may be from previous run)
// CLEAN_EXIT:  log was already written in ST-04 — do NOT write again
// ERROR:       attempt to write whatever log data we have accumulated
if (isRealError && runLog && runLog !== "[]" && runId) {
    try {
        var writeResult = JSON.parse(System.getModule(MODULE).writeLogFile(
            runLog, runId, dryRun || false
        ));
        if (writeResult.success) {
            System.log("[EH] Partial audit log written: " + writeResult.filePath);
        } else {
            System.warn("[EH] Audit log write failed: " + (writeResult.error || "unknown"));
        }
    } catch (e) {
        System.warn("[EH] Could not write audit log during exception handling: " + e.message);
    }
}

// ── Release mutex lock ────────────────────────────────────────────────────────
// Only release if:
//   - We have a lockEl reference (i.e. ST-02 ran and acquired the lock)
//   - This is NOT a MUTEX_ABORT (the lock belongs to another run — never touch it)
if (!isMutexAbort && lockEl) {
    try {
        var currentLock = lockEl.getAttributeWithKey("runLock").value || "";
        if (currentLock === runId) {
            // Only release if the lock still bears our run ID
            lockEl.setAttributeWithKey("runLock", "");
            System.log("[EH] Mutex released by exception handler: " + runId);
        } else if (currentLock !== "") {
            System.warn("[EH] Lock value (" + currentLock + ") does not match our runId (" +
                        runId + ") — not releasing. Possible concurrent modification.");
        }
        // If currentLock is "" it was already released (e.g. ST-04 clean exit) — no action needed
    } catch (le) {
        System.error("[EH] CRITICAL: Could not release mutex lock! " +
                     "Manual clear required in SnapshotCleanup/RuntimeState. Error: " + le.message);
    }
} else if (isMutexAbort) {
    System.log("[EH] MUTEX_ABORT — not releasing lock (not ours).");
} else if (!lockEl) {
    System.warn("[EH] lockEl is null — lock was never acquired (error occurred before ST-02 completed).");
}

// ── Write run summary ─────────────────────────────────────────────────────────
var summary = {
    runId:          runId || "UNKNOWN",
    completedAt:    new Date().toISOString(),
    outcome:        workflowOutcome,
    errorMessage:   isRealError ? errorMsg : null,
    lockReleased:   (!isMutexAbort && lockEl !== null)
};
runSummaryJson = JSON.stringify(summary, null, 2);

System.log("[EH] Handler complete. Outcome: " + workflowOutcome);

// For CLEAN_EXIT and MUTEX_ABORT, do NOT re-throw — workflow ends without error state
// For real errors, re-throw so vRO marks the workflow run as failed
if (isRealError) {
    throw new Error(errorMsg);
}
