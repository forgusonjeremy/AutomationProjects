/**
 * ST-03  ENUMERATE vCENTERS & COLLECT CANDIDATES
 * ─────────────────────────────────────────────────────────────────────────────
 * Iterates over all vCenter SDK connections registered in the embedded vRO
 * appliance. For each vCenter, calls the getSnapshotCandidates action which
 * walks the full VM inventory, evaluates snapshot trees, and applies the age,
 * name, and description filters.
 *
 * Results from all vCenters are merged into a single flat JSON array.
 * Each candidate object is annotated with its source vCenter name so that
 * downstream tasks can route tasks back to the correct SDK connection.
 *
 * Enumeration errors on individual vCenters are caught and logged — a single
 * unreachable vCenter does not abort the run; remaining vCenters are still
 * processed.
 *
 * ── WORKFLOW ATTRIBUTE INPUTS ────────────────────────────────────────────────
 *   Name              Type    Description
 *   ────────────────────────────────────────────────────────────────────────
 *   runId             string  For log entry annotation
 *   runLog            string  JSON array — log entries appended here
 *   maxAgeMinutes     number  Passed through to getSnapshotCandidates
 *   nameMatchString   string  Passed through to getSnapshotCandidates
 *   descIgnoreString  string  Passed through to getSnapshotCandidates
 *
 * ── WORKFLOW ATTRIBUTE OUTPUTS ───────────────────────────────────────────────
 *   Name                Type    Description
 *   ────────────────────────────────────────────────────────────────────────
 *   allCandidatesJson   string  JSON array of candidate snapshot objects,
 *                               annotated with vcenterName on each entry.
 *                               Empty array "[]" if no candidates found.
 *   runLog              string  Updated JSON array with any enum_error entries
 *
 * ── CANDIDATE OBJECT SCHEMA ──────────────────────────────────────────────────
 *   {
 *     vmMoRef             : string,   // VM managed object reference
 *     vmName              : string,
 *     vmPowerState        : string,   // "poweredOn" | "poweredOff" | "suspended"
 *     snapshotMoRef       : string,
 *     snapshotName        : string,
 *     snapshotDesc        : string,
 *     snapshotCreatedMs   : number,   // epoch ms
 *     snapshotAgeMinutes  : number,
 *     datastoreMoRefs     : string[], // one per datastore the VM uses
 *     parentSnapshotMoRef : string | null,
 *     vcenterName         : string    // injected here — name of source vCenter
 *   }
 */

var MODULE = "com.company.snapshotcleanup";
var logEntries = JSON.parse(runLog || "[]");
var allCandidates = [];

// ── Validate vCenter connections are available ────────────────────────────────
var allVcenters = VcPlugin.allSdkConnections;
if (!allVcenters || allVcenters.length === 0) {
    System.warn("[ST-03] No vCenter connections found in vRO inventory.");
    allCandidatesJson = "[]";
    runLog = JSON.stringify(logEntries);
    // ST-04 will detect empty candidates and trigger an early clean exit
    System.log("[ST-03] allCandidatesJson = [] (no vCenter connections)");
} else {
    System.log("[ST-03] Found " + allVcenters.length + " vCenter connection(s)");

    for each (var vc in allVcenters) {
        var vcName = vc.name || vc.url;
        System.log("[ST-03] Enumerating: " + vcName);

        try {
            var candidatesJson = System.getModule(MODULE).getSnapshotCandidates(
                vc,
                maxAgeMinutes    || 60,
                nameMatchString  || "",
                descIgnoreString || ""
            );

            var candidates = JSON.parse(candidatesJson);
            System.log("[ST-03]   -> " + candidates.length + " candidate(s) on " + vcName);

            // Annotate each candidate with the vCenter name so downstream tasks
            // know which SDK connection to use for deletion.
            // NOTE: We cannot serialise the vc SDK object itself to JSON, so we
            // store vcenterName as a string and re-resolve in ST-06/ST-07 by
            // matching against VcPlugin.allSdkConnections by name.
            for each (var c in candidates) {
                c.vcenterName = vcName;
            }

            allCandidates = allCandidates.concat(candidates);

        } catch (e) {
            System.error("[ST-03] Enumeration failed for " + vcName + ": " + e.message);
            logEntries.push({
                timestampMs:        new Date().getTime(),
                runId:              runId,
                vCenter:            vcName,
                vmName:             "",
                vmPowerState:       "",
                snapshotName:       "",
                snapshotDesc:       "",
                snapshotAgeMinutes: 0,
                action:             "enum_error",
                success:            false,
                skipReason:         null,
                datastoreMoRefs:    [],
                durationMs:         0,
                error:              e.message
            });
        }
    }

    allCandidatesJson = JSON.stringify(allCandidates);
    runLog = JSON.stringify(logEntries);

    System.log("[ST-03] Total candidates across all vCenters: " + allCandidates.length);
}
