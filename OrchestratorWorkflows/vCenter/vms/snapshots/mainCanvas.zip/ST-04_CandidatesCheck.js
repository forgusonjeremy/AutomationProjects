/**
 * ST-04  CANDIDATES CHECK (EARLY EXIT GATE)
 * ─────────────────────────────────────────────────────────────────────────────
 * Evaluates whether any snapshot candidates were found across all vCenters.
 * If none were found, this task performs a clean shutdown:
 *   1. Writes the (minimal) audit log to the network share
 *   2. Releases the mutex lock
 *   3. Throws to exit the workflow cleanly
 *
 * When candidates ARE found, this task does nothing and the workflow continues
 * to ST-05.
 *
 * WHY A SEPARATE TASK:
 *   In a multi-task vRO workflow, you cannot perform a conditional early exit
 *   from within a task and have the workflow simply "stop". Throwing an error
 *   routes to the Exception Handler. We use a dedicated decision-branch
 *   approach: connect ST-04's success output to ST-05, and add a workflow
 *   Decision element before ST-05 that checks candidateCount > 0. However,
 *   the cleanest vRO pattern without a Decision element is to throw here when
 *   empty — the Exception Handler then sees the CLEAN_EXIT sentinel value and
 *   skips the error log, just releases the lock. Both patterns are described
 *   below; implement whichever suits your canvas layout preference.
 *
 * PATTERN A — Use this script + Exception Handler sentinel check (simpler canvas):
 *   Exception Handler script checks if error message starts with "CLEAN_EXIT:"
 *   and treats it as a successful no-op run rather than a failure.
 *
 * PATTERN B — Add a vRO Decision element after ST-04 (cleaner visual):
 *   Bind candidateCount as an output of ST-04.
 *   Decision: if candidateCount == 0 → route to ST-08 (write log) → ST-09 (release)
 *             if candidateCount  > 0 → route to ST-05 (sort & split)
 *
 * This file implements PATTERN A.
 *
 * ── WORKFLOW ATTRIBUTE INPUTS ────────────────────────────────────────────────
 *   Name                Type    Description
 *   ────────────────────────────────────────────────────────────────────────
 *   allCandidatesJson   string  JSON array from ST-03
 *   runLog              string  Current log JSON array
 *   runId               string  For log/release
 *   lockEl              ConfigurationElement  Mutex element reference
 *   dryRun              boolean For writeLogFile call
 *
 * ── WORKFLOW ATTRIBUTE OUTPUTS ───────────────────────────────────────────────
 *   Name            Type    Description
 *   ────────────────────────────────────────────────────────────────────────
 *   candidateCount  number  Count of candidates (0 triggers early exit)
 *                           Downstream Decision element uses this if using Pattern B
 *
 * ── THROWS (Pattern A only) ──────────────────────────────────────────────────
 *   "CLEAN_EXIT: No snapshot candidates found." — Exception Handler treats as success
 */

var MODULE = "com.company.snapshotcleanup";
var candidates = JSON.parse(allCandidatesJson || "[]");
candidateCount = candidates.length;

System.log("[ST-04] Candidate count: " + candidateCount);

if (candidateCount === 0) {
    System.log("[ST-04] No candidates found — performing clean exit.");

    // Write the (minimal) audit log — captures any enum_errors from ST-03
    try {
        var writeResult = JSON.parse(System.getModule(MODULE).writeLogFile(
            runLog,
            runId,
            dryRun
        ));
        if (writeResult.success) {
            System.log("[ST-04] Audit log written: " + writeResult.filePath);
        } else {
            System.warn("[ST-04] Audit log write failed: " + writeResult.error);
        }
    } catch (e) {
        System.warn("[ST-04] writeLogFile threw during clean exit: " + e.message);
    }

    // Release the mutex lock before exiting
    try {
        lockEl.setAttributeWithKey("runLock", "");
        System.log("[ST-04] Mutex released (clean exit): " + runId);
    } catch (le) {
        System.error("[ST-04] CRITICAL: Could not release lock on clean exit! " +
                     "Manual clear required. " + le.message);
    }

    // Throw with sentinel prefix so Exception Handler can distinguish this
    // from a real failure and not log it as an error
    throw new Error("CLEAN_EXIT: No snapshot candidates found across any vCenter. " +
                    "Run completed successfully with no actions taken.");
}

System.log("[ST-04] " + candidateCount + " candidate(s) found — continuing to ST-05.");
