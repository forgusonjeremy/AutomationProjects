/**
 * ST-06  PROCESS POWERED-ON VMs (THROTTLED LANE)
 * ─────────────────────────────────────────────────────────────────────────────
 * Processes the powered-on / suspended VM candidate queue with:
 *   - Per-vCenter grouping (candidates processed per-vCenter sequentially;
 *     true cross-vCenter parallelism requires a Parallel workflow element
 *     invoking a sub-workflow — see notes below)
 *   - Per-vCenter concurrency limit (maxParallel simultaneous tasks)
 *   - Full adaptive I/O governor pre-check before each task
 *   - Complete VM safety checks inside deleteSnapshot action
 *
 * PARALLELISM NOTE:
 *   vRO's sequential scriptable task model means this loop runs one task at
 *   a time per vCenter (inFlight counter is a sequential approximation).
 *   For true parallelism, replace this task with a vRO Parallel element that
 *   spawns one instance of a "Process vCenter Queue" sub-workflow per vCenter.
 *   The datastoreStateJson output must then be merged from all sub-workflow
 *   outputs before ST-07 runs.
 *
 * ── WORKFLOW ATTRIBUTE INPUTS ────────────────────────────────────────────────
 *   Name                     Type    Description
 *   ──────────────────────────────────────────────────────────────────────────
 *   onCandidatesJson         string  Powered-on candidates from ST-05
 *   runId                    string  For log entry annotation
 *   runLog                   string  Current log JSON — entries appended here
 *   dryRun                   boolean Skip actual deletion when true
 *   latencyThresholdMs       number  VMFS/NFS governor threshold
 *   vsanCongestionThresh     number  vSAN governor threshold
 *   vsanResyncThresholdBytes number  vSAN resync queue threshold in bytes
 *   govPollMs                number  Governor polling interval in ms
 *   maxParallel              number  Max concurrent tasks per vCenter
 *   taskTimeoutSeconds       number  Per-task vCenter task timeout
 *
 * ── WORKFLOW ATTRIBUTE OUTPUTS ───────────────────────────────────────────────
 *   Name                Type    Description
 *   ──────────────────────────────────────────────────────────────────────────
 *   datastoreStateJson  string  Governor calibration state (pre/post metrics
 *                               per datastore). Passed into ST-07 so the
 *                               powered-off fast lane inherits calibration
 *                               data from powered-on consolidations.
 *   runLog              string  Updated JSON log array
 */

var MODULE = "com.company.snapshotcleanup";
var onCandidates  = JSON.parse(onCandidatesJson  || "[]");
var logEntries    = JSON.parse(runLog || "[]");
var datastoreState = {}; // [dsRef] = { lastPre: metricsObj, lastPost: metricsObj }

System.log("[ST-06] Processing " + onCandidates.length + " powered-on VM candidate(s).");

if (onCandidates.length === 0) {
    System.log("[ST-06] No powered-on candidates — skipping.");
    datastoreStateJson = "{}";
    runLog = JSON.stringify(logEntries);
} else {

    // ── Group candidates by vCenter name ──────────────────────────────────────
    var byVcenter = {};
    for each (var c in onCandidates) {
        if (!byVcenter[c.vcenterName]) byVcenter[c.vcenterName] = [];
        byVcenter[c.vcenterName].push(c);
    }

    // ── Process each vCenter's queue ──────────────────────────────────────────
    for (var vcKey in byVcenter) {
        var vcQueue = byVcenter[vcKey];
        System.log("[ST-06] vCenter: " + vcKey + " — " + vcQueue.length + " candidates");

        // Resolve the live SDK connection by name
        var vcConn = null;
        var allVCs = VcPlugin.allSdkConnections;
        for each (var sdkConn in allVCs) {
            if ((sdkConn.name || sdkConn.url) === vcKey) {
                vcConn = sdkConn;
                break;
            }
        }
        if (!vcConn) {
            System.error("[ST-06] Could not resolve SDK connection for: " + vcKey + " — skipping queue.");
            continue;
        }

        var inFlight = 0;

        for (var i = 0; i < vcQueue.length; i++) {
            var candidate = vcQueue[i];
            var dsRefs = candidate.datastoreMoRefs || [];

            // ── Concurrency throttle ────────────────────────────────────────
            // Sequential model: inFlight tracks the conceptual slot count.
            // In a true parallel implementation this would be semaphore-based.
            while (inFlight >= maxParallel) {
                System.sleep(2000);
                inFlight = Math.max(0, inFlight - 1);
            }

            // ── Adaptive governor pre-check ─────────────────────────────────
            var governorApproved = checkGovernor(vcConn, dsRefs, candidate.vmName, datastoreState);

            if (!governorApproved) {
                var pollAttempts  = 0;
                var maxPollAttempts = 120; // 60 min at 30s default
                while (!governorApproved && pollAttempts < maxPollAttempts) {
                    System.log("[ST-06] Governor HOLD for VM=" + candidate.vmName +
                               " (attempt " + (pollAttempts + 1) + "/" + maxPollAttempts + ")");
                    System.sleep(govPollMs);
                    pollAttempts++;
                    governorApproved = checkGovernor(vcConn, dsRefs, candidate.vmName, datastoreState);
                }

                if (!governorApproved) {
                    System.warn("[ST-06] Governor max wait exceeded for VM=" + candidate.vmName +
                                " snap=" + candidate.snapshotName + " — deferring.");
                    logEntries.push(makeEntry(candidate, "deferred", false,
                                              "Governor max wait exceeded", null, 0));
                    continue;
                }
            }

            // ── Execute deletion ────────────────────────────────────────────
            inFlight++;
            var resultJson = System.getModule(MODULE).deleteSnapshot(
                vcConn,
                candidate.vmMoRef,
                candidate.snapshotMoRef,
                candidate.snapshotName,
                candidate.vmName,
                JSON.stringify(dsRefs),
                dryRun,
                taskTimeoutSeconds || 1800
            );
            inFlight = Math.max(0, inFlight - 1);

            var res = JSON.parse(resultJson);

            // ── Calibrate governor with observed pre/post delta ─────────────
            if (!dryRun && res.success && !res.skipped) {
                var preArr  = JSON.parse(res.preMetricsJson  || "[]");
                var postArr = JSON.parse(res.postMetricsJson || "[]");
                for each (var pm in preArr) {
                    if (!datastoreState[pm.datastoreMoRef]) datastoreState[pm.datastoreMoRef] = {};
                    datastoreState[pm.datastoreMoRef].lastPre = pm;
                }
                for each (var pm2 in postArr) {
                    if (!datastoreState[pm2.datastoreMoRef]) datastoreState[pm2.datastoreMoRef] = {};
                    datastoreState[pm2.datastoreMoRef].lastPost = pm2;
                }
            }

            // ── Build and push log entry ────────────────────────────────────
            var action = dryRun ? "dry_run"
                       : res.skipped ? "skipped"
                       : res.success ? "deleted"
                       : "error";
            logEntries.push(makeEntry(candidate, action,
                res.success || (dryRun && !res.skipped),
                res.skipReason, res.error, res.durationMs));
        }
    }

    datastoreStateJson = JSON.stringify(datastoreState);
    runLog = JSON.stringify(logEntries);
    System.log("[ST-06] Powered-on lane complete.");
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function checkGovernor(vcConn, dsRefs, vmName, dsState) {
    if (!dsRefs || dsRefs.length === 0) return true;

    var currentMetrics = [];
    for each (var dsRef in dsRefs) {
        try {
            currentMetrics.push(JSON.parse(
                System.getModule(MODULE).getDatastoreMetrics(vcConn, dsRef)
            ));
        } catch (e) {
            System.warn("[ST-06] Could not sample datastore " + dsRef + ": " + e.message);
        }
    }

    var preArr = [], postArr = [];
    for each (var dsRef2 in dsRefs) {
        var st = dsState[dsRef2];
        if (st) {
            if (st.lastPre)  preArr.push(st.lastPre);
            if (st.lastPost) postArr.push(st.lastPost);
        }
    }

    var govResult = JSON.parse(System.getModule(MODULE).adaptiveGovernorCheck(
        JSON.stringify(currentMetrics),
        JSON.stringify(preArr),
        JSON.stringify(preArr),
        JSON.stringify(postArr),
        latencyThresholdMs       || 30,
        vsanCongestionThresh     || 50,
        vsanResyncThresholdBytes || 10737418240
    ));

    if (!govResult.approved) {
        System.log("[ST-06] Governor DENY for VM=" + vmName + ": " + govResult.reason);
    }
    return govResult.approved;
}

function makeEntry(candidate, action, success, skipReason, error, durationMs) {
    return {
        timestampMs:        new Date().getTime(),
        runId:              runId,
        vCenter:            candidate.vcenterName || "",
        vmName:             candidate.vmName      || "",
        vmPowerState:       candidate.vmPowerState || "",
        snapshotName:       candidate.snapshotName || "",
        snapshotDesc:       candidate.snapshotDesc || "",
        snapshotAgeMinutes: candidate.snapshotAgeMinutes || 0,
        action:             action,
        success:            success,
        skipReason:         skipReason || null,
        datastoreMoRefs:    candidate.datastoreMoRefs || [],
        durationMs:         durationMs || 0,
        error:              error || null
    };
}
